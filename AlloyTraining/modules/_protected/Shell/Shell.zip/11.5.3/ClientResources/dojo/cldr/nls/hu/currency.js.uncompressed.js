define(
"dojo/cldr/nls/hu/currency", //begin v1.x content
{
	"HKD_displayName": "Hongkongi dollár",
	"CHF_displayName": "Svájci frank",
	"JPY_symbol": "¥",
	"CAD_displayName": "Kanadai dollár",
	"HKD_symbol": "HKD",
	"CNY_displayName": "Kínai jüan renminbi",
	"USD_symbol": "$",
	"AUD_displayName": "Ausztrál dollár",
	"JPY_displayName": "Japán jen",
	"CAD_symbol": "CAD",
	"USD_displayName": "USA dollár",
	"EUR_symbol": "EUR",
	"CNY_symbol": "CNY",
	"GBP_displayName": "Brit font sterling",
	"GBP_symbol": "GBP",
	"AUD_symbol": "AUD",
	"EUR_displayName": "Euro"
}
//end v1.x content
);